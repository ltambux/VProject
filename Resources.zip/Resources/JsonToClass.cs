﻿namespace VProject.Model;

public class JsonToClass{
    
}